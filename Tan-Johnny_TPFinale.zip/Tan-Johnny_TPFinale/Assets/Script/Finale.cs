using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Finale : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (SceneManager.GetActiveScene().name == "finaleGagne")
        {
            if (Input.GetKeyDown(KeyCode.Space))            // Si la touche Espace est enfonc�e
            {
                SceneManager.LoadScene("intro");          // Charge la sc�ne "intro"
            }
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.Space))            // Si la sc�ne active n'est pas "finaleGagne"
            {
                SceneManager.LoadScene("PointDeControle");      // Charge la sc�ne "PointDeControle"
            }
        }
    }
}
