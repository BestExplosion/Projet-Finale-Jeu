using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class intro : MonoBehaviour
{

    void Update() //Code pour commencer le jeu lorsqu'on clique sur "espace"
    {
        if(Input.GetKeyDown(KeyCode.Space))
        {
            SceneManager.LoadScene("PointDeControle");            //Charger PointDeControle
        }
    }
}
