using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouvementSuiviEtLimites : MonoBehaviour
{
    public GameObject cibleASuivre; // La cible que la cam�ra doit suivre

    public float limiteGauche;  // Limite gauche de la cam�ra
    public float limiteDroite;   // Limite droite de la cam�ra
    public float limiteHaut;    // Limite haute de la cam�ra
    public float limiteBas; // Limite basse de la cam�ra

    // Update is called once per frame
    void Update()
    {
        Vector3 laPosition = cibleASuivre.transform.position;  // � chaque frame, met � jour la position de la cam�ra pour suivre la cible

        if (laPosition.x < limiteGauche) laPosition.x = limiteGauche;
        if (laPosition.x > limiteDroite) laPosition.x = limiteDroite;
        if (laPosition.y < limiteBas) laPosition.y = limiteBas;
        if (laPosition.y > limiteHaut) laPosition.y = limiteHaut;

        laPosition.z = -10f; // Ajuste la profondeur (z) pour que la cam�ra soit devant les objets du jeu
        transform.position = laPosition; // Applique la nouvelle position � la cam�ra


    }
}
