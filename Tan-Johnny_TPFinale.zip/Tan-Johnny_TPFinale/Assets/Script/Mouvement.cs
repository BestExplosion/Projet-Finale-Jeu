using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.SceneManagement;


public class Mouvement : MonoBehaviour
{
    public float vitesseX;               //vitesse horizontale actuelle
    public float vitesseXMax;            //vitesse horizontale Maximale d�sir�e
    public float vitesseY;               //vitesse verticale 
    public float vitesseSaut;            //vitesse de saut d�sir�e

    public int attaqueConteur;           //Conteur d'attaque sur le boss

    bool partieTerminee;                 //Lorsque la partie est termin�e
    bool attaque;                        //lorsqu'on attaque


    public AudioClip sonMort;             //Audio mort
    public AudioClip sonMortMonstre;      //Audio mort Monstre
    public AudioClip sonAttaque;          //Audio attaque

    //D�tection des touches et modification de la vitesse de d�placement;
    void Update()
    {

        if (!partieTerminee)
        {
            // d�placement vers la gauche avec a ou fl�che gauche
            if (Input.GetKey("a") || Input.GetKey(KeyCode.LeftArrow))
            {
                vitesseX = -vitesseXMax;
                GetComponent<SpriteRenderer>().flipX = true;

            }  // d�placement vers la gauche avec d ou fl�che droite
            else if (Input.GetKey("d") || Input.GetKey(KeyCode.RightArrow))   //d�placement vers la droite
            {
                vitesseX = vitesseXMax;
                GetComponent<SpriteRenderer>().flipX = false;
            }
            else
            {
                vitesseX = GetComponent<Rigidbody2D>().velocity.x;  //m�morise vitesse actuelle en X
            }

            // sauter l'objet � l'aide la touche w ou fl�che haut 
            if (Input.GetKeyDown("w") && Physics2D.OverlapCircle(transform.position,  1f) || Input.GetKeyDown(KeyCode.UpArrow) && Physics2D.OverlapCircle(transform.position, 1f))
            {
                vitesseY = vitesseSaut;
                GetComponent<Animator>().SetBool("saut", true);
            }
            else
            {
                vitesseY = GetComponent<Rigidbody2D>().velocity.y;  //vitesse actuelle verticale
                GetComponent<Animator>().SetBool("saut", false);

            }

            //Gestion Attaque
            if (Input.GetKeyDown(KeyCode.Space) && attaque == false)
            {                                                                        
                attaque = true;
                Invoke("AnnulerAttaque", 0.4f);                                      //Gestion Attaque       
                GetComponent<Animator>().SetTrigger("attaque");
                GetComponent<Animator>().SetBool("saut", false);
            }

            if (attaque == true && vitesseX <= vitesseXMax && vitesseX >= -vitesseXMax)
            {

                vitesseX *= 4;

            }
            //Applique les vitesses en X et Y
            GetComponent<Rigidbody2D>().velocity = new Vector2(vitesseX, vitesseY);
     //**************************Gestion des animaitons de course et de repos********************************
            

            if (vitesseX > 0.1f || vitesseX < -0.1f)
            {

                GetComponent<Animator>().SetBool("Course", true);
            }
            else                                                    //Active l'animation de course si la vitesse de d�placement n'est pas 0, sinon le repos sera jouer par Animator
            {

                GetComponent<Animator>().SetBool("Course", false);
            }

        }
    }
    void OnCollisionEnter2D(Collision2D infoCollision)
    {   
        if (Physics2D.OverlapCircle(transform.position, 0.5f))
        {
            GetComponent<Animator>().SetBool("saut", false);                    //Code qui fait en sorte que le personnage peut seulement sauter apr�s toucher le sol
        }
        else if (infoCollision.gameObject.name == "Ennemi")
        {

            if (attaque == true)
            {

                Destroy(infoCollision.gameObject);                              //Enlever monstre
                GetComponent<AudioSource>().PlayOneShot(sonAttaque);            //son attaque
                GetComponent<AudioSource>().PlayOneShot(sonMortMonstre);        //Son mort 

            }
            else
            {
                GetComponent<Animator>().SetTrigger("mort");                    //Mort du personnage
                Invoke("recommencer", 1f);                                      //Sc�ne de mort
                GetComponent<AudioSource>().PlayOneShot(sonMort);               //Son mort    

            }
        }
        //Il faut esquiver le champignon (ne peut pas tuer)
        if (infoCollision.gameObject.name == "EnnemiEsquiver")
        {
            GetComponent<Animator>().SetTrigger("mort");                        //Mort du personnage
            Invoke("recommencer", 1f);                                          //Sc�ne de mort
            GetComponent<AudioSource>().PlayOneShot(sonMort);                   //Son mort
        }
        if (infoCollision.gameObject.name == "Boss")                            //Attaque au boss
        {
            if(attaque == true)
            {
                attaqueConteur += 1;
                GetComponent<AudioSource>().PlayOneShot(sonAttaque);            //Jouer son attaque
                if (attaqueConteur == 3)                                        //Attaque 3x pour tuer le boss
                {
                   Destroy(infoCollision.gameObject);                           //enl�ve le boss
                    GetComponent<AudioSource>().PlayOneShot(sonMort);           //son mort Boss
                }
            }
            else
            {
                GetComponent<Animator>().SetTrigger("mort");                    //Mort du personnage
                Invoke("recommencer", 1f);                                      //Sc�ne de mort
                GetComponent<AudioSource>().PlayOneShot(sonMort);               //Son mort    

            }
        }
    }
    //Prendre l'�p�e pour gagner
    private void OnTriggerEnter2D(Collider2D infoCollision)
    {
        if (infoCollision.gameObject.name == "arme")                            // Ce qui se passe lorsque le chevalier prend l'arme
        {
            Destroy(infoCollision.gameObject);                                  //Enlever l'arme
            SceneManager.LoadScene("finaleGagne");                              //Sc�ne gagne
        }
    }
    //recommencer le jeu
    void recommencer()
    {

        SceneManager.LoadScene("finaleMort");                                   // Ce qui se passe lorsque le jeu termine (mauvais)
    }

    void AnnulerAttaque()
    {
        attaque = false;                                                        //Un seul attaque
    }
}

